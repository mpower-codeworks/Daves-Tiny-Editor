ml /c /coff /IC:\masm32\include dte.asm

link dte.obj ^
/SUBSYSTEM:WINDOWS ^
/ENTRY:MainEntry ^
/LIBPATH:"C:\Program Files (x86)\Windows Kits\10\Lib\10.0.20348.0\um\x86" ^
kernel32.lib user32.lib shell32.lib ^
/OUT:dte.exe

del dte.obj